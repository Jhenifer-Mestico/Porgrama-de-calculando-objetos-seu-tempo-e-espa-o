/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tresobj;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class TresObj {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String texto;
         float dist, tempo, velocidade;
         Scanner inputData = new Scanner(System.in);
    System.out.println("Digite o primeiro objeto:");
    texto = inputData.nextLine(); 
    
     System.out.println("Digite distância do objeto");
    dist = inputData.nextFloat(); 
    
     System.out.println("Digite o tempo percorrido:");
    tempo = inputData.nextFloat(); 
    
    velocidade = dist/tempo;
    
     System.out.println("A velocdade é :" + velocidade);
    
    }
}
